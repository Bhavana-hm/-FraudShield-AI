# FraudShield AI – Intelligent Credit Card Fraud Detection System

## Overview
FraudShield AI is an academic machine-learning project that analyses anonymized credit-card transaction features and predicts the probability of a transaction being fraudulent. It includes a Streamlit dashboard for single and bulk prediction, analytics, and model-performance review.

> This is a student demonstration using a historical anonymized dataset. It is not connected to a bank, payment gateway, or live transaction network.

## Dataset
- Dataset: Credit Card Fraud Detection (Kaggle)
- Original shape: 284,807 rows × 31 columns
- Duplicate records removed: 1,081
- Cleaned shape: 283,726 rows × 31 columns
- Genuine transactions: 283,253
- Fraud transactions: 473
- Features: `Time`, `V1`–`V28`, `Amount`
- Target: `Class` (`0` = genuine, `1` = fraud)

Confirm the exact Kaggle dataset URL and license from the original download page. A commonly used page is https://www.kaggle.com/datasets/mlg-ulb/creditcardfraud.

## Methodology
1. Inspect dataset structure and quality.
2. Remove duplicate rows.
3. Separate target (`Class`) from 30 input features.
4. Perform a stratified 80:20 train-test split.
5. Apply SMOTE only to training data.
6. Compare Random Forest, XGBoost, Decision Tree, Logistic Regression and Isolation Forest.
7. Select Random Forest for the final model.
8. Evaluate on held-out test data.
9. Load the saved model in the Streamlit dashboard.

## Model Comparison
| Model | Precision | Recall | F1 | ROC-AUC | PR-AUC |
|---|---:|---:|---:|---:|---:|
| Random Forest | 0.8902 | 0.7684 | 0.8249 | 0.9609 | 0.8043 |
| XGBoost | 0.5878 | 0.8105 | 0.6814 | 0.9701 | 0.8004 |
| Decision Tree | 0.2451 | 0.7895 | 0.3741 | 0.8936 | 0.4443 |
| Logistic Regression | 0.1424 | 0.8526 | 0.2440 | 0.9629 | 0.7027 |
| Isolation Forest | 0.1280 | 0.1684 | 0.1455 | 0.9293 | 0.0704 |

## Final Random Forest Test Results
- Precision: 91.36%
- Recall: 77.89%
- F1 score: 84.09%
- Threshold: 0.50
- Confusion matrix: `[[56644, 7], [21, 74]]`
- TN 56,644; FP 7; FN 21; TP 74.

The model-comparison metrics and final test metrics are separate evaluation results and should not be mixed.

## Dashboard Pages
Home; Fraud Detection; Bulk Detection; Analytics; Model Performance.

## Run Locally
```bash
python -m pip install -r requirements.txt
python -m streamlit run app/dashboard.py
```
Open the local address printed in the terminal, usually `http://localhost:8501`.

## Input Format
Bulk CSV prediction requires `Time`, `V1` through `V28`, and `Amount`. An optional `Class` column is not used as a prediction input. V1–V28 are anonymized transformed variables, not cardholder details.

## Limitations
Historical anonymized data; no live banking integration; fixed demonstration threshold; requires independent validation and security review before any operational deployment.

## Academic Submission Checklist
- [ ] Verify Kaggle dataset URL and license.
- [ ] Add student USN and project guide details.
- [ ] Insert actual dashboard screenshots.
- [ ] Verify at least four EDA visualizations and notebook observations.
- [ ] Review report against college guidelines.
- [ ] Prepare a 5–7 minute presentation and viva.
